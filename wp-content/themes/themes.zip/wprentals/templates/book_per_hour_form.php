<div id="book_per_hour_wrapper">
    <div class="book_per_hour_back">
    </div>   
    <div id="book_per_hour">
        <div id="book_per_hour_close">x</div>
        <div id="book_per_hour_calendar"></div>
        <div id="book_per_hour_footer_toolbar">
            <button id="per_hour_cancel" class="wpb_btn-info wpb_btn-small wpestate_vc_button  vc_button">
                <?php esc_html_e('Cancel','wprentals');?>
            </button>
            <button id="per_hour_ok" class="wpb_btn-info wpb_btn-small wpestate_vc_button  vc_button">
                <?php esc_html_e('Ok','wprentals');?>
            </button>
        </div>
    </div>
</div>