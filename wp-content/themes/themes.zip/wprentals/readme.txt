Theme Name: WpRentals
Theme URI: http://themeforest.net/user/wpestate
Description: Ultimate WordPress Theme created by WP Estate for accommodation booking. WP Rentals is clean, flexible, fully responsive and retina Ready. Its smart settings allows you to build outstanding renting websites easy and fast.
Version: 3.10.0
Author: http://wpestate.org/
Author URI: http://themeforest.net/user/wpestate
Text Domain: wprentals
Tags: white, one-column, two-columns,left-sidebar, right-sidebar, fluid-layout , custom-menu, theme-options, translation-ready
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

For help files go here https://help.wprentals.net/