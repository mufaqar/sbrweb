<?php
 print wpestate_convert_dateformat_reverse($booking_from_date).' <strong>'.esc_html__( 'to','wprentals').'</strong> '.wpestate_convert_dateformat_reverse($booking_to_date);
 ?>
