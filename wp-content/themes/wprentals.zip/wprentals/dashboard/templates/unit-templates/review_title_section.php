<div class="prop-info">
    <h4 class="listing_title_book book_listing_user_title">
        <?php
        print '<a href="'.esc_url (get_permalink($propertyId) ).'">'.get_the_title($propertyId).'</a>';
        ?>
    </h4>
</div>